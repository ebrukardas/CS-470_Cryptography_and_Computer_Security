from lib import *
from aesLib import *

def aesTest():

	rKey = [	[0x2b, 0x28, 0xab, 0x09],
				[0x7e, 0xae, 0xf7, 0xcf],
				[0x15, 0xd2, 0x15, 0x4f],
				[0x16, 0xa6, 0x88, 0x3c] ]
	m1 = createStateMatrix(Data2, len)
	m1 = ToHexArray(m1)

	rKey = ToHexArray(rKey)

	print("Plain:")
	printMatrix(m1)

	print("\nRound key:")
	printMatrix(rKey)
	cp = aes(m1, rKey)

	print("\nCrypted:")
	printMatrix(cp)


if __name__ == "__main__":
	aesTest()

