from aes import *


def test(cleartext, keysize=16, modeName = "CBC"):
	#Test with random key, choice of mode
	print('Mode:', modeName)
	print('cleartext:', cleartext)
	key =  generateRandomKey(keysize)
	#print( 'Key:', [ord(x) for x in key])
	mode = AESModeOfOperation.modeOfOperation[modeName]
	cipher = encryptData(key, cleartext, mode)
	print '\nCipher:\n', [ord(x) for x in cipher]
	decr = decryptData(key, cipher, mode)
	print 'Plain:\n', decr

if __name__ == "__main__":
	modChoice = AESModeOfOperation()
	cleartext = "Ebru Kardas Gebze Teknik Universitesi"
	cipherKey = [143,194,34,208,145,203,230,143,177,246,97,206,145,92,255,84]
	iv = [103,35,148,239,76,213,47,118,255,222,123,176,106,134,98,92]
	mode, orig_len, ciph = modChoice.encrypt(cleartext, modChoice.modeOfOperation["CBC"],
			cipherKey, modChoice.aes.keySize["SIZE_128"], iv)
	print('m=%s, \nol=%s (%s), \ncipher=%s' % (mode, orig_len, len(cleartext), ciph))
	decr = modChoice.decrypt(ciph, orig_len, mode, cipherKey,
			modChoice.aes.keySize["SIZE_128"], iv)
	print(decr)
	print("\n")

	test(cleartext, 16, "CBC")
	print("\n")

	test(cleartext, 16, "OFB")

